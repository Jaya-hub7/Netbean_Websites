import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/QuestionServlet")
public class QuestionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve mail_id from the request
        String mailId = request.getParameter("mid");

        // Assuming correct answers (you may want to retrieve these from a database)
        String[] correctAnswers = {"A", "B", "B", "B", "D"};

        // Retrieve user answers
        String[] userAnswers = new String[5];
        for (int i = 1; i <= 5; i++) {
            String paramName = "q" + i;
            String userAnswer = request.getParameter(paramName);
            userAnswers[i - 1] = userAnswer;
        }
        
        // Evaluate the answers and calculate the score
        int score = 0;
        for (int i = 0; i < 5; i++) {
            if (userAnswers[i] != null && userAnswers[i].equals(correctAnswers[i])) {
                score += 5; // Each correct answer is worth 5 marks
            }
        }
        
        out.println("<style>header {\n" +
"            background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent black background for better readability */\n" +
"            color: white;\n" +
"            padding: 20px;\n" +
"            font-family: cursive;\n" +
"            font-size: 27px;\n" +
"            margin-left: 4px;\n" +
"            text-align: center;\n" +
"        }.container {\n" +
"            text-align: center;\n" +
"            background-color: CC3437;\n" +
"            padding: 20px;\n" +
"            border-radius: 10px;\n" +
"            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\n" +
"        }\n" +
"\n" +
"        h1 {\n" +
"            color: #3498db;\n" +
"        }\n" +
"\n" +
"        p {\n" +
"            font-size: 30px;\n" +
"            color: black;\n" +
"        }.button-container {\n" +
"            margin-top: 20px;\n" +
"        }.btn {\n" +
"            padding: 10px 20px;\n" +
"            font-size: 1em;\n" +
"            margin: 0 10px;\n" +
"            cursor: pointer;\n" +
"        }</style>");
        
        out.println("<body>");
        out.println("<header> QUIZ-APPLICATION</header><br><br><br><br><br><br>");
        out.println("<div class=\"container\">\n" +
"    <h1>Hurray! You Have Completed Quiz</h1>\n" +
"    <p><b>Your Score : " + score+"<b></p>\n" );
        
        out.println("<form ><input type=submit formaction=crtans.html value=\"View Correct Answer\" class=btn></form></div></body>");
        storeScoreInDatabase(mailId, score, out);
    }

    private void storeScoreInDatabase(String mailId, int score, PrintWriter out) {
         String url = "jdbc:mysql://localhost:3306/quiz";
         String driver = "com.mysql.cj.jdbc.Driver";
         String userName = "root";
         String passwordDB = "admin123";

     try {
        // Load the JDBC driver
        Class.forName(driver).newInstance();

        // Establish a connection
        Connection conn = DriverManager.getConnection(url, userName, passwordDB);

        // Retrieve user_id using mail_id
        int userId = getUserIdByMailId(mailId, conn);

        if (userId != -1) {
            // If user_id is available, check if the user has already taken the quiz
            String checkScoreQuery = "SELECT score FROM users WHERE user_id=?";
            try (PreparedStatement checkScorePst = conn.prepareStatement(checkScoreQuery)) {
                checkScorePst.setInt(1, userId);
                ResultSet resultSet = checkScorePst.executeQuery();

                if (resultSet.next()) {
                    int existingScore = resultSet.getInt("score");
                    if (existingScore != 0) {
                        // User has already taken the quiz, display an alert message
                        out.println("<script>\n" +
                                "    var confirmation = confirm(\"You have already taken this quiz.\");\n" +
                                "    if (confirmation) {\n" +
                                "        window.location.href = \"index.html\";\n" +
                                "    } else {\n" +
                                "        window.location.href = \"index.html\";\n" +
                                "    }\n" +
                                "</script>");
                        return;
                    }
                }
            }

            // Update the existing record with the new score
            String updateQuery = "UPDATE users SET score=? WHERE user_id=?";
            try (PreparedStatement updatePst = conn.prepareStatement(updateQuery)) {
                updatePst.setInt(1, score);
                updatePst.setInt(2, userId);
                updatePst.executeUpdate();
            }
        } else {
            // If user_id doesn't exist, display an alert message
            out.println("<script>\n" +
                    "    var confirmation = confirm(\"User ID not found for the provided Mail ID\");\n" +
                    "    if (confirmation) {\n" +
                    "        window.location.href = \"question.html\";\n" +
                    "    } else {\n" +
                    "        window.location.href = \"index.html\";\n" +
                    "    }\n" +
                    "</script>");
        }

        // Close the connection
        conn.close();
    } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
        e.printStackTrace();
    }
}

    private int getUserIdByMailId(String mailId, Connection conn) throws SQLException {
        // Check if the mail_id exists in the table and retrieve user_id
        String selectQuery = "SELECT user_id FROM users WHERE mail_id=?";
        try (PreparedStatement selectPst = conn.prepareStatement(selectQuery)) {
            selectPst.setString(1, mailId);
            ResultSet resultSet = selectPst.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("user_id");
            } else {
                return -1; // Indicates that user_id is not found
            }
        }
    }
}
